function App() {
  return (
    <div className="text-3xl font-bold text-red-500">
      Tailwind is working 🎉
    </div>
  );
}

export default App;
